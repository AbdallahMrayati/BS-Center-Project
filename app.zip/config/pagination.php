<?php

return [
    'per_page' => 5, // Default items per page
];
