// const courses = [
//     {
//         link: "/pages/course.html",
//         title: "Strategic planning in healthcare organizations",
//     },
//     {
//         link: "/pages/course.html",
//         title: "Strategic planning in healthcare organizations",
//     },
//     {
//         link: "/pages/course.html",
//         title: "Strategic planning in healthcare organizations",
//     },
//     {
//         link: "/pages/course.html",
//         title: "Strategic planning in healthcare organizations",
//     },
//     {
//         link: "/pages/course.html",
//         title: "Strategic planning in healthcare organizations",
//     },
//     {
//         link: "/pages/course.html",
//         title: "Strategic planning in healthcare organizations",
//     },
//     {
//         link: "/pages/course.html",
//         title: "Strategic planning in healthcare organizations",
//     },
//     {
//         link: "/pages/course.html",
//         title: "Strategic planning in healthcare organizations",
//     },
// ];

// courses.map((item) => {
//     document.querySelector(".courses-items").innerHTML += `
//         <a class="course-item" href=${item.link}>
//           <p>${item.title}</p>
//           <span href=${item.link}>
//             <img src="../assets/icons/arrow.svg" alt="" />
//           </span>
//         </a>
//   `;
// });
